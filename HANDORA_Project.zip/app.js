/* ==========================================================================
   HANDORA - Core Application Engine & Master Voice AI
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  // State Management
  let isSubscribedToBlue = false;
  let activeFilter = 'all';
  let currentActivePostId = null;
  let isAiVoiceListening = false;
  let isSpeaking = false;

  // Mock Database
  const storiesData = [
    { id: 's1', username: 'CyberSam', avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80', isVerified: true, hasVoice: true },
    { id: 's2', username: 'Elena_R', avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80', isVerified: false, hasVoice: false },
    { id: 's3', username: 'TechAura', avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80', isVerified: true, hasVoice: true },
    { id: 's4', username: 'SophiaVoice', avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=150&q=80', isVerified: true, hasVoice: true },
    { id: 's5', username: 'Quantum_Dev', avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=150&q=80', isVerified: false, hasVoice: false },
  ];

  let postsData = [
    {
      id: 1,
      username: 'HANDORA_Official',
      userAvatar: 'assets/master_ai_avatar.jpg',
      isVerified: true,
      isAiGenerated: true,
      timeAgo: '10m ago',
      location: 'Silicon Valley • HANDORA AI Hub',
      mediaUrl: 'assets/futuristic_post_1.jpg',
      caption: 'Welcome to HANDORA! Explore social media powered by autonomous Master Voice AI intelligence. Subscribe to HANDORA Blue via UPI (sriaswin642@okaxis) to get verified!',
      hashtags: '#HANDORA #HANDORAAI #VoiceSocial #FutureOfSocial',
      likes: 1248,
      isLiked: false,
      isSaved: false,
      hasVoiceNarration: true,
      voiceTranscript: '"HANDORA Master AI active: Feed synchronized with voice synthesis."',
      comments: [
        { id: 'c1', username: 'CyberSam', isVerified: true, text: 'This HANDORA voice assistant integration is mind blowing! 🚀', time: '5m' },
        { id: 'c2', username: 'Elena_R', isVerified: false, text: 'Just paid via sriaswin642@okaxis for HANDORA Blue! Got verified!', time: '2m' }
      ]
    },
    {
      id: 2,
      username: 'CyberSam',
      userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
      isVerified: true,
      isAiGenerated: false,
      timeAgo: '1h ago',
      location: 'Tokyo, Japan',
      mediaUrl: 'https://images.unsplash.com/photo-1508873696983-2df515122519?auto=format&fit=crop&w=800&q=80',
      caption: 'Late night cyberpunk vibes in Shinjuku. Recorded a quick voice log describing the neon lights atmosphere!',
      hashtags: '#Tokyo #NeonNights #HANDORA #Cyberpunk',
      likes: 852,
      isLiked: true,
      isSaved: true,
      hasVoiceNarration: true,
      voiceTranscript: '"Walking through the rain-slick streets of Shinjuku with glowing billboards..."',
      comments: [
        { id: 'c3', username: 'SophiaVoice', isVerified: true, text: 'Awesome colors! Did HANDORA AI generate your voice caption?', time: '45m' }
      ]
    },
    {
      id: 3,
      username: 'SophiaVoice',
      userAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=150&q=80',
      isVerified: true,
      isAiGenerated: false,
      timeAgo: '3h ago',
      location: 'Acoustic Sound Studio',
      mediaUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?auto=format&fit=crop&w=800&q=80',
      caption: 'Testing the new HANDORA Blue VIP Voice Synthesizer. Clear audio frequency response and instant translation!',
      hashtags: '#VoiceStudio #HANDORABlue #AudioTech #Verified',
      likes: 2190,
      isLiked: false,
      isSaved: false,
      hasVoiceNarration: true,
      voiceTranscript: '"Audio frequency test 1-2-3. HANDORA AI voice enhancement enabled."',
      comments: [
        { id: 'c4', username: 'HANDORA_Official', isVerified: true, text: 'HANDORA AI audio enhancement rating: 100% crystal clear!', time: '2h' }
      ]
    }
  ];

  const suggestedUsers = [
    { username: 'DesignMaster', avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80', subtitle: 'Followed by CyberSam' },
    { username: 'Neural_Art', avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=150&q=80', subtitle: 'Suggested HANDORA Creator' },
    { username: 'SoundScaper', avatar: 'https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?auto=format&fit=crop&w=150&q=80', subtitle: 'Voice Artist • Verified' }
  ];

  // DOM Elements Initialization
  const storiesListEl = document.getElementById('storiesList');
  const postsFeedEl = document.getElementById('postsFeed');
  const suggestionsListEl = document.getElementById('suggestionsList');

  // Modals & Drawers
  const aiDrawerOverlay = document.getElementById('aiDrawerOverlay');
  const subModalOverlay = document.getElementById('subModalOverlay');
  const commentsModalOverlay = document.getElementById('commentsModalOverlay');
  const createPostModalOverlay = document.getElementById('createPostModalOverlay');

  // Voice AI Elements
  const voiceWaveCanvas = document.getElementById('voiceWaveCanvas');
  const ctx = voiceWaveCanvas ? voiceWaveCanvas.getContext('2d') : null;
  const masterAiCore = document.getElementById('masterAiCore');
  const aiConversationLog = document.getElementById('aiConversationLog');
  const drawerVoiceStatus = document.getElementById('drawerVoiceStatus');

  // Init App
  initStories();
  initPostsFeed();
  initSuggestions();
  initAudioVisualizer();
  initUpiCopyButton();

  // ================= STORIES RENDERER =================
  function initStories() {
    storiesListEl.innerHTML = storiesData.map(story => `
      <div class="story-item">
        <div class="story-ring ${story.isVerified ? 'verified-ring' : ''}">
          <div class="story-avatar">
            <img src="${story.avatar}" alt="${story.username}">
          </div>
        </div>
        <span class="story-username">${story.username}</span>
      </div>
    `).join('');
  }

  // ================= SUGGESTIONS RENDERER =================
  function initSuggestions() {
    suggestionsListEl.innerHTML = suggestedUsers.map(user => `
      <div class="suggestion-item">
        <div class="sug-user-info">
          <img src="${user.avatar}" class="sug-avatar" alt="${user.username}">
          <div class="sug-details">
            <span class="sug-name-row">${user.username} <i class="fa-solid fa-circle-check blue-tick"></i></span>
            <span class="sug-sub">${user.subtitle}</span>
          </div>
        </div>
        <button class="btn-follow">Follow</button>
      </div>
    `).join('');
  }

  // ================= POSTS FEED RENDERER =================
  function initPostsFeed() {
    let filtered = postsData;
    if (activeFilter === 'voice') filtered = postsData.filter(p => p.hasVoiceNarration);
    if (activeFilter === 'verified') filtered = postsData.filter(p => p.isVerified);
    if (activeFilter === 'ai') filtered = postsData.filter(p => p.isAiGenerated);

    postsFeedEl.innerHTML = filtered.map(post => `
      <article class="post-card" data-id="${post.id}">
        <!-- Post Header -->
        <div class="post-header">
          <div class="post-user-info">
            <div class="post-user-avatar">
              <img src="${post.userAvatar}" alt="${post.username}">
            </div>
            <div class="post-user-details">
              <div class="post-username-row">
                <span class="post-username">${post.username}</span>
                ${post.isVerified ? '<span class="verified-badge"><i class="fa-solid fa-circle-check"></i></span>' : ''}
              </div>
              <span class="post-location">${post.location} • ${post.timeAgo}</span>
            </div>
          </div>
          <button class="post-options-btn"><i class="fa-solid fa-ellipsis"></i></button>
        </div>

        <!-- Post Media -->
        <div class="post-media-container" onclick="handlePostDoubleTap(${post.id}, event)">
          <img src="${post.mediaUrl}" alt="Post media">
          <div class="double-tap-heart" id="heart-pop-${post.id}">
            <i class="fa-solid fa-heart"></i>
          </div>

          ${post.hasVoiceNarration ? `
            <div class="post-voice-overlay">
              <button class="voice-play-btn" onclick="event.stopPropagation(); playPostVoice(${post.id})">
                <i class="fa-solid fa-play" id="play-icon-${post.id}"></i>
              </button>
              <div class="voice-info">
                <span class="voice-label"><i class="fa-solid fa-waveform"></i> Voice Audio Note</span>
                <span class="voice-transcript">${post.voiceTranscript}</span>
              </div>
            </div>
          ` : ''}
        </div>

        <!-- Post Action Bar -->
        <div class="post-actions">
          <div class="action-group">
            <button class="post-action-btn ${post.isLiked ? 'liked' : ''}" onclick="toggleLike(${post.id})">
              <i class="${post.isLiked ? 'fa-solid' : 'fa-regular'} fa-heart"></i>
            </button>
            <button class="post-action-btn" onclick="openCommentsModal(${post.id})">
              <i class="fa-regular fa-comment"></i>
            </button>
            <button class="post-action-btn" onclick="speakPostCaption(${post.id})">
              <i class="fa-solid fa-volume-high"></i>
            </button>
            <button class="post-action-btn ai-action" onclick="askMasterAiAboutPost(${post.id})" title="Ask HANDORA AI">
              <i class="fa-solid fa-wand-magic-sparkles"></i>
            </button>
          </div>
          <button class="post-action-btn" onclick="toggleSave(${post.id})">
            <i class="${post.isSaved ? 'fa-solid' : 'fa-regular'} fa-bookmark"></i>
          </button>
        </div>

        <!-- Likes Count -->
        <div class="post-likes-count">${post.likes.toLocaleString()} likes</div>

        <!-- Caption -->
        <div class="post-caption-box">
          <span class="caption-username">${post.username}</span>
          ${post.caption} <span class="hashtags">${post.hashtags}</span>
        </div>

        <!-- View Comments Link -->
        <div class="post-comments-view-all" onclick="openCommentsModal(${post.id})">
          View all ${post.comments.length} comments & voice replies...
        </div>
      </article>
    `).join('');
  }

  // ================= FEED TAB FILTERS =================
  document.querySelectorAll('.feed-tab').forEach(tab => {
    tab.addEventListener('click', (e) => {
      document.querySelectorAll('.feed-tab').forEach(t => t.classList.remove('active'));
      e.target.classList.add('active');
      activeFilter = e.target.getAttribute('data-filter');
      initPostsFeed();
    });
  });

  // ================= INTERACTION HANDLERS =================
  window.toggleLike = function(postId) {
    const post = postsData.find(p => p.id === postId);
    if (!post) return;
    post.isLiked = !post.isLiked;
    post.likes += post.isLiked ? 1 : -1;
    initPostsFeed();
  };

  window.toggleSave = function(postId) {
    const post = postsData.find(p => p.id === postId);
    if (!post) return;
    post.isSaved = !post.isSaved;
    showToast(post.isSaved ? 'Post saved to your collection!' : 'Removed from collection');
    initPostsFeed();
  };

  window.handlePostDoubleTap = function(postId, event) {
    const post = postsData.find(p => p.id === postId);
    if (!post) return;

    if (!post.isLiked) {
      post.isLiked = true;
      post.likes += 1;
      initPostsFeed();
    }

    const heartEl = document.getElementById(`heart-pop-${postId}`);
    if (heartEl) {
      heartEl.classList.add('animate');
      setTimeout(() => heartEl.classList.remove('animate'), 800);
    }
  };

  // ================= VOICE SPEECH SYNTHESIS ENGINE =================
  function speakText(text, onEndCallback) {
    if (!('speechSynthesis' in window)) {
      showToast(text, 'toast-blue');
      if (onEndCallback) onEndCallback();
      return;
    }

    window.speechSynthesis.cancel(); // Stop any active speech
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1.0;
    utterance.pitch = 1.05;

    // Pick best voice if available
    const voices = window.speechSynthesis.getVoices();
    const googleVoice = voices.find(v => v.name.includes('Google') || v.name.includes('Natural') || v.name.includes('Samantha') || v.lang.startsWith('en'));
    if (googleVoice) utterance.voice = googleVoice;

    isSpeaking = true;
    updateAiOrbListeningState(true);

    utterance.onend = () => {
      isSpeaking = false;
      updateAiOrbListeningState(false);
      if (onEndCallback) onEndCallback();
    };

    window.speechSynthesis.speak(utterance);
  }

  window.speakPostCaption = function(postId) {
    const post = postsData.find(p => p.id === postId);
    if (!post) return;
    speakText(`HANDORA Post by ${post.username}: ${post.caption}`);
    showToast(`🔊 Reading HANDORA post by ${post.username}`, 'toast-blue');
  };

  window.playPostVoice = function(postId) {
    const post = postsData.find(p => p.id === postId);
    if (!post) return;
    const playIcon = document.getElementById(`play-icon-${postId}`);
    if (playIcon) playIcon.className = 'fa-solid fa-pause';

    speakText(post.voiceTranscript || post.caption, () => {
      if (playIcon) playIcon.className = 'fa-solid fa-play';
    });
  };

  window.askMasterAiAboutPost = function(postId) {
    const post = postsData.find(p => p.id === postId);
    if (!post) return;
    openAiDrawer();
    addChatMessage('user', `What can HANDORA AI tell me about ${post.username}'s post?`);
    setTimeout(() => {
      const response = `HANDORA AI Analysis: ${post.username}'s post has ${post.likes} likes and top engagement. Would you like me to auto-generate a voice comment with your ${isSubscribedToBlue ? 'HANDORA Blue Verified mark' : 'account'}?`;
      addChatMessage('ai', response);
      speakText(response);
    }, 600);
  };

  // ================= MASTER VOICE AI DRAWER =================
  const openAiAssistantBtn = document.getElementById('openAiAssistantBtn');
  const closeAiDrawerBtn = document.getElementById('closeAiDrawerBtn');
  const activateVoiceAiBtn = document.getElementById('activateVoiceAiBtn');
  const drawerMicBtn = document.getElementById('drawerMicBtn');
  const drawerSendBtn = document.getElementById('drawerSendBtn');
  const drawerTextInput = document.getElementById('drawerTextInput');

  openAiAssistantBtn.addEventListener('click', openAiDrawer);
  activateVoiceAiBtn.addEventListener('click', openAiDrawer);
  closeAiDrawerBtn.addEventListener('click', closeAiDrawer);

  function openAiDrawer() {
    aiDrawerOverlay.classList.add('active');
  }
  function closeAiDrawer() {
    aiDrawerOverlay.classList.remove('active');
    window.speechSynthesis.cancel();
  }

  function addChatMessage(role, text) {
    const bubbleHtml = `
      <div class="chat-bubble ${role}-bubble">
        <div class="bubble-avatar"><i class="fa-solid fa-${role === 'ai' ? 'robot' : 'user'}"></i></div>
        <div class="bubble-text">${text}</div>
      </div>
    `;
    aiConversationLog.insertAdjacentHTML('beforeend', bubbleHtml);
    aiConversationLog.scrollTop = aiConversationLog.scrollHeight;
  }

  function handleUserVoiceCommand(userText) {
    if (!userText.trim()) return;
    addChatMessage('user', userText);
    drawerTextInput.value = '';

    const lower = userText.toLowerCase();
    let aiResponse = "";

    if (lower.includes('summarize') || lower.includes('feed')) {
      aiResponse = `Here is your HANDORA Feed Summary: You have 3 top posts today. CyberSam shared a futuristic Tokyo voice log, and SophiaVoice released an audio studio test. Engagement is up 34%!`;
    } else if (lower.includes('blue') || lower.includes('verify') || lower.includes('subscribe') || lower.includes('upi')) {
      aiResponse = `HANDORA Blue subscription gives you the official Blue Checkmark badge! You can pay directly via UPI ID sriaswin642@okaxis. Opening subscription options now.`;
      setTimeout(openSubscriptionModal, 1500);
    } else if (lower.includes('read') || lower.includes('top')) {
      const topPost = postsData[0];
      aiResponse = `Reading top post from ${topPost.username}: "${topPost.caption}"`;
    } else {
      aiResponse = `HANDORA Voice AI processed your command: "${userText}". How else can I assist your HANDORA experience?`;
    }

    setTimeout(() => {
      addChatMessage('ai', aiResponse);
      speakText(aiResponse);
    }, 600);
  }

  drawerSendBtn.addEventListener('click', () => {
    handleUserVoiceCommand(drawerTextInput.value);
  });
  drawerTextInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') handleUserVoiceCommand(drawerTextInput.value);
  });

  // Voice Mic Listening Simulation / WebSpeech Recognition
  function toggleVoiceRecognition() {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognition = new SpeechRecognition();
      recognition.lang = 'en-US';

      updateAiOrbListeningState(true);
      drawerVoiceStatus.innerText = "Listening to your voice... Speak now!";

      recognition.onresult = (event) => {
        const transcript = event.results[0][0].transcript;
        handleUserVoiceCommand(transcript);
        updateAiOrbListeningState(false);
      };
      recognition.onerror = () => {
        simulatedVoiceCommand();
      };
      recognition.start();
    } else {
      simulatedVoiceCommand();
    }
  }

  function simulatedVoiceCommand() {
    updateAiOrbListeningState(true);
    drawerVoiceStatus.innerText = "Listening to your voice... (HANDORA Voice Engine)";
    const sampleCommands = [
      "HANDORA AI, summarize my feed",
      "Pay via sriaswin642@okaxis to get verified",
      "Read the top caption aloud",
      "Generate an AI voice caption for my post"
    ];
    const picked = sampleCommands[Math.floor(Math.random() * sampleCommands.length)];

    setTimeout(() => {
      updateAiOrbListeningState(false);
      drawerVoiceStatus.innerText = `Recognized: "${picked}"`;
      handleUserVoiceCommand(picked);
    }, 1800);
  }

  drawerMicBtn.addEventListener('click', toggleVoiceRecognition);
  if (masterAiCore) masterAiCore.addEventListener('click', toggleVoiceRecognition);

  function updateAiOrbListeningState(listening) {
    if (masterAiCore) {
      if (listening) masterAiCore.classList.add('listening');
      else masterAiCore.classList.remove('listening');
    }
  }

  // Quick Command Buttons in Sidebar
  document.querySelectorAll('.quick-cmd-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const cmd = e.currentTarget.getAttribute('data-cmd');
      if (cmd === 'summarize') handleUserVoiceCommand('Summarize my feed');
      if (cmd === 'readpost') speakPostCaption(1);
      if (cmd === 'voicecaption') handleUserVoiceCommand('Generate an AI voice caption');
      if (cmd === 'subscribe') openSubscriptionModal();
    });
  });

  // ================= HANDORA BLUE SUBSCRIPTION & UPI GATEWAY =================
  const getVerifiedBtn = document.getElementById('getVerifiedBtn');
  const sideSubscribeBtn = document.getElementById('sideSubscribeBtn');
  const navSubscribe = document.getElementById('navSubscribe');
  const closeSubModalBtn = document.getElementById('closeSubModalBtn');
  const confirmSubscribeBtn = document.getElementById('confirmSubscribeBtn');
  const toggleSubStateBtn = document.getElementById('toggleSubStateBtn');

  getVerifiedBtn.addEventListener('click', openSubscriptionModal);
  if (sideSubscribeBtn) sideSubscribeBtn.addEventListener('click', openSubscriptionModal);
  navSubscribe.addEventListener('click', openSubscriptionModal);
  closeSubModalBtn.addEventListener('click', closeSubscriptionModal);

  function openSubscriptionModal() {
    subModalOverlay.classList.add('active');
  }
  function closeSubscriptionModal() {
    subModalOverlay.classList.remove('active');
  }

  function initUpiCopyButton() {
    const copyUpiBtn = document.getElementById('copyUpiBtn');
    if (!copyUpiBtn) return;
    copyUpiBtn.addEventListener('click', () => {
      const upiText = 'sriaswin642@okaxis';
      navigator.clipboard.writeText(upiText).then(() => {
        showToast('📋 UPI ID sriaswin642@okaxis copied to clipboard!', 'toast-blue');
        speakText('UPI ID copied to clipboard');
      }).catch(() => {
        showToast('UPI ID: sriaswin642@okaxis');
      });
    });
  }

  function activateBlueSubscription() {
    isSubscribedToBlue = true;
    closeSubscriptionModal();
    updateUserBlueStatusInUI();
    showToast('🎉 UPI Payment Confirmed to sriaswin642@okaxis! You are now HANDORA Blue Verified!', 'toast-blue');
    speakText('Payment confirmed to sriaswin642@okaxis. Welcome to HANDORA Blue Verified status! Your account now displays the official Blue Checkmark badge everywhere.');
  }

  confirmSubscribeBtn.addEventListener('click', activateBlueSubscription);

  toggleSubStateBtn.addEventListener('click', () => {
    isSubscribedToBlue = !isSubscribedToBlue;
    updateUserBlueStatusInUI();
    showToast(isSubscribedToBlue ? 'HANDORA Blue Verified Activated!' : 'Verification Disabled');
  });

  function updateUserBlueStatusInUI() {
    const userBlueBadges = document.querySelectorAll('.user-blue-check');
    const sideBlueBanner = document.getElementById('sideBlueBanner');

    userBlueBadges.forEach(badge => {
      if (isSubscribedToBlue) badge.classList.remove('hidden');
      else badge.classList.add('hidden');
    });

    if (sideBlueBanner) {
      if (isSubscribedToBlue) {
        sideBlueBanner.style.borderColor = '#0095f6';
        sideBlueBanner.querySelector('h4').innerText = 'HANDORA Blue Active ✓';
        sideBlueBanner.querySelector('p').innerText = 'Verified via sriaswin642@okaxis! Your Blue Checkmark and Voice AI super-powers are active!';
        sideBlueBanner.querySelector('button').innerText = 'Manage VIP Membership';
      } else {
        sideBlueBanner.querySelector('h4').innerText = 'HANDORA Verified';
        sideBlueBanner.querySelector('p').innerText = 'Get the Blue Checkmark badge via UPI payment (sriaswin642@okaxis) + HANDORA Voice AI!';
        sideBlueBanner.querySelector('button').innerText = 'Upgrade to Blue';
      }
    }
  }

  // ================= COMMENTS SYSTEM =================
  window.openCommentsModal = function(postId) {
    currentActivePostId = postId;
    const post = postsData.find(p => p.id === postId);
    if (!post) return;

    const commentsContainer = document.getElementById('commentsContainer');
    commentsContainer.innerHTML = post.comments.map(c => `
      <div class="comment-item">
        <img src="https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80" class="comment-avatar" alt="${c.username}">
        <div class="comment-content">
          <div class="comment-author-row">
            <span>${c.username}</span>
            ${c.isVerified ? '<i class="fa-solid fa-circle-check blue-tick"></i>' : ''}
            <span class="comment-time">${c.time}</span>
          </div>
          <div>${c.text}</div>
        </div>
      </div>
    `).join('');

    commentsModalOverlay.classList.add('active');
  };

  document.getElementById('closeCommentsBtn').addEventListener('click', () => {
    commentsModalOverlay.classList.remove('active');
  });

  document.getElementById('sendCommentBtn').addEventListener('click', postComment);

  function postComment() {
    const input = document.getElementById('commentTextInput');
    const text = input.value.trim();
    if (!text || !currentActivePostId) return;

    const post = postsData.find(p => p.id === currentActivePostId);
    if (post) {
      post.comments.push({
        id: 'c' + Date.now(),
        username: 'alex_morgan',
        isVerified: isSubscribedToBlue,
        text: text,
        time: 'Just now'
      });
      input.value = '';
      openCommentsModal(currentActivePostId);
      initPostsFeed();
      showToast('Comment posted!');
    }
  }

  // Voice Comment Dictation
  document.getElementById('voiceCommentBtn').addEventListener('click', () => {
    showToast('🎙️ Dictate your voice comment to HANDORA AI...', 'toast-blue');
    speakText('Speak your comment aloud now.');
    setTimeout(() => {
      document.getElementById('commentTextInput').value = "HANDORA voice comment: Love this futuristic post!";
      showToast('Voice comment dictated. Click Post!');
    }, 2000);
  });

  // ================= CREATE POST MODAL =================
  const createPostBtn = document.getElementById('createPostBtn');
  const closeCreatePostBtn = document.getElementById('closeCreatePostBtn');
  const generateAiCaptionBtn = document.getElementById('generateAiCaptionBtn');
  const submitPostBtn = document.getElementById('submitPostBtn');
  const postCaptionInput = document.getElementById('postCaptionInput');

  createPostBtn.addEventListener('click', () => createPostModalOverlay.classList.add('active'));
  closeCreatePostBtn.addEventListener('click', () => createPostModalOverlay.classList.remove('active'));

  generateAiCaptionBtn.addEventListener('click', () => {
    postCaptionInput.value = "Exploring the next generation of voice-guided social media with #HANDORA and Master Voice Assistant! 🚀";
    showToast('✨ HANDORA AI generated caption!', 'toast-blue');
    speakText('HANDORA AI generated your voice post caption.');
  });

  submitPostBtn.addEventListener('click', () => {
    const caption = postCaptionInput.value.trim() || 'New HANDORA post!';
    const newPost = {
      id: Date.now(),
      username: 'alex_morgan',
      userAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
      isVerified: isSubscribedToBlue,
      isAiGenerated: false,
      timeAgo: 'Just now',
      location: 'HANDORA Studio',
      mediaUrl: 'assets/futuristic_post_1.jpg',
      caption: caption,
      hashtags: '#NewPost #HANDORA',
      likes: 1,
      isLiked: true,
      isSaved: false,
      hasVoiceNarration: true,
      voiceTranscript: `"${caption}"`,
      comments: []
    };

    postsData.unshift(newPost);
    initPostsFeed();
    createPostModalOverlay.classList.remove('active');
    postCaptionInput.value = '';
    showToast('🎉 Your new HANDORA post is live!', 'toast-blue');
  });

  // ================= TOAST NOTIFICATION HELPER =================
  function showToast(message, extraClass = '') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast ${extraClass}`;
    toast.innerHTML = `<i class="fa-solid fa-bell"></i> <span>${message}</span>`;
    container.appendChild(toast);
    setTimeout(() => toast.remove(), 3500);
  }

  // ================= AUDIO CANVAS VISUALIZER =================
  function initAudioVisualizer() {
    if (!ctx) return;
    let waveOffset = 0;

    function renderWave() {
      ctx.clearRect(0, 0, voiceWaveCanvas.width, voiceWaveCanvas.height);
      ctx.lineWidth = 2;
      ctx.strokeStyle = isSpeaking ? '#00f2fe' : 'rgba(0, 242, 254, 0.4)';

      ctx.beginPath();
      const width = voiceWaveCanvas.width;
      const height = voiceWaveCanvas.height;
      const mid = height / 2;

      for (let x = 0; x < width; x++) {
        const amplitude = isSpeaking ? 14 : 4;
        const y = mid + Math.sin((x * 0.05) + waveOffset) * amplitude;
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      waveOffset += isSpeaking ? 0.2 : 0.05;
      requestAnimationFrame(renderWave);
    }
    renderWave();
  }
});
